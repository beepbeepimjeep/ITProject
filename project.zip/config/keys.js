module.exports = {
    googleClientID: "527993252939-44to7kuc70ftju2nisi25enf15re76tk.apps.googleusercontent.com",
    googleClientSecret: "39Dhfv18KsnWck61R-D8NoM6",
    cookieKey: 'ajfweijfwfjoawjrcaoijp',
    linkedinClientID: "86e6jxqwjuety1",
    linkedinClientSecret: "ykVvmiTuq93JBceJ",
    emailAccount: "myeportfoliounimelb@gmail.com",
    emailPassword:"ITProject2020"
}

